	 	 <div class="section post medium-post post-content col-sm-5"  style="display: inline-block; margin: 2% ;float : left;">								
														
			<h2 class="entry-title" style="display: inline-block; margin: 2% ;float : left;">

				<a href="news-details.html"  style="float : left; display: inline-block;">

				Our closest relatives aren't fans of daylight saving time
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

				</a>
				<br>
				<a href="index.php" style="font-weight: normal;">Read More...</a>
			
			</h2>
		</div>
	
