
	<header style="max-width: 80%; padding-left: 15%;  align-content: center";>
			<div class="navbar sticky-nav navbar-inverse " role="banner" >				
				<div class="container-fluid">	
					<div class="navbar-header">
												
						<a class="navbar-brand" href="index.php">
							<img class="main-logo img-responsive " style="position: relative;
    width: 170px;
    left: 15px;
    max-height: 70px; " src="logo.jpg" alt="NewsPress">
						</a>
					</div> 
					<nav id="mainmenu" class="navbar-left collapse navbar-collapse"> 
						<ul class="nav navbar-nav">                       
							<li class="sports"><a href="index.php" >Home</a></li>
							<li class="sports"><a href="business.php">Business</a></li>
							<li class="sports"><a href="politics.php" >Politics</a></li>
							<li class="sports"><a href="sports.php">Sports</a></li>
							<li class="health"><a href="health.php">Health</a></li>
							<li class="sports"><a href="entertainment.php">Entertainment</a></li>
							<li class="sports"><a href="contact-us2.php">Contact Us</a></li>
							</li>
						</ul> 					
					</nav>
					
				</div>
			</div>
		</header><!--/#navigation--> 


</div>