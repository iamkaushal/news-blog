<footer id="footer">
		<div class="footer-top">
			<div class="container text-center">
				<div class="logo-icon"><img class="img-responsive" src="images/presets/preset1/logo-icon.png" alt="" /></div>
			</div>
		</div>
		<div class="footer-menu">
			<div class="container">
				<ul class="nav navbar-nav">                       
					<li><a href="index.php">Home</a></li>
					<!-- <li><a href="index.php">About</a></li> -->
					<li><a href="contact-us2.php">Contact Us</a></li>
				</ul> 
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container text-center">
				<p><a href="#">Made  by Kaushal </a>&copy; 2018 </p>
			</div>
		</div>		
	</footer>