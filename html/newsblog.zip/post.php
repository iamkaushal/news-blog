<?php 
	require_once('header.php');
 ?>

    <title>News Press | Home</title>
	
<body>

	<?php 

// 		echo <<<END

// 		kausalsharkajsdkfjdas
// 		kasjfkadsflksjdf
// 		askfjasl;''
// 		flds

// END;

		require('topnav.php');

		echo "<div class='container'>";

	    $id = $_GET['id'];
 		
 	
 		require_once('dbconnect.php');

				$sql = "SELECT * FROM posts WHERE id=".$id  ;
				
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
				    // output data of each row
				    
				    while($row = $result->fetch_assoc()) {

				        echo "<h1>" ,$row["title"] , "</h1>","<br>", "<article style='font-size: 110%; font-family:Helvetica'>" , nl2br($row["post"] ), "</article>" ;
				    	
				    }
				} else {
				    echo "0 results";
				}

				$conn->close();

				require('footer.php');

		echo "</div>";


 	 ?>
 	

</body>
</html>